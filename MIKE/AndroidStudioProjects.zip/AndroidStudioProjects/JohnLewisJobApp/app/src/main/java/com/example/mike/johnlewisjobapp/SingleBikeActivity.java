package com.example.mike.johnlewisjobapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Mike on 29/07/2016.
 */
public class SingleBikeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singlebike);

        final Button bStart = (Button) findViewById(R.id.bStart);

        bStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backToStartIntent = new Intent(SingleBikeActivity.this, MainActivity.class);
                SingleBikeActivity.this.startActivity(backToStartIntent);
            }

        });
    }
}

